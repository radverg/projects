 <article id="version1.6up">
        <header>
          <h2> Nadcházející verze 1.6 - informace: (15.10.2015): </h2>
        </header>
        <section>
          <li>Změněna technologie ukládání a načítání dat.</li>
          <li>Přidána možnost měnit maximální a minimální velikost bludiště.</li> 
          <li>Změny v menu jsou vždy uloženy, když hráč vypne nebo restartuje klienta použitím tlačítka "Apply changes".</li>
          <li>Opravena střela "Chuck Norris" - střepiny mají stejný směr a rychlost na různých rozlišeních.</li>      
        </section>           
      </article>
      
      <article id="version1.5downl">
        <header>
          <h2> Verze 1.5 - informace: (9.10.2015): </h2>
        </header>
        <section>
          <li>Plošný laser má stejnou rychlost na různých rozlišeních.</li>
          <li>Je možno zapínat a vypínat vertikální synchronizaci a stabilní fps.</li>
          <li>Pokud je hráč mrtvý, může posouvat s kamerou pomocí šipek.</li>
          <li>Tloušťka zdí je stejná na různých rozlišeních.</li>
          <li>Tank se nestává neovladatelným ve chvíli, kdy jiný hráč právě umírá.</li>
          <li>Přidány nové zvuky.</li> 
          <li>Pozice tanků jsou přesnější.</li>
          <li>Zbraně se objevují pouze v oblastech, kam se dá dostat.</li>
          <li>1 hráč potřebuje minimálně 1 vlastní čtverec - to znamená, že pokud zde budou například 4 hráči, budou zde minimálně 4 dosažitelné čtverce pro všechny hráče. (Zatím to ale nefunguje :D)</li>
          <br>      
            <a href="downloads/TankHunt1_5.zip" class="download">STÁHNOUT TANK HUNT 1.5</a><br><br>
        </section>           
      </article>
      
      <article id="version1.4downl">
        <header>
          <h2> Verze 1.4 - informace: (4.10.2015)</h2>
        </header>
        <section>
           <li>Opravena chyba způsobující více smrtí tanku ve stejné hře.</li>
           <li>Opravena chyba způsobující špatný odraz střely od stěny. </li>
           <li>Jízda dozadu je zpomalena.</li>
           <li>Hráči si mohou nastavit libovolné rozlišení, ovšem nejvyšší nastavitelné rozlišení je maximální rozlišení monitoru.</li>
           <li>Je možné nastavit fullscreen kliknutím na klávesu F11.</li>
           <li>Novinka: některé zdi se zbarvují podle barvy tanků ve hře. Tank může projet stejně zbarvenou zdí, jako je barva tanku, ale jiný hráč touto zdí neprojede.</li>
           <li>Hráči se objevují na takových pozicích, aby k sobě mohli dojet.</li><br>      
            <a href="downloads/TankHunt1_4.zip" class="download">STÁHNOUT TANK HUNT 1.4</a><br><br>
        </section>           
      </article>
      
      <article id="version1.3downl">
        <header>
          <h2> Verze 1.3 - vydána 16.9.2015: </h2>
          
        </header>  
        <section>
               <a href="downloads/TankHunt1_3.zip" class="download">STÁHNOUT TANK HUNT 1.3</a>  <br><br>
        </section>           
      </article>
      